import React from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import Home from './routes/Home'
import Blog from './routes/Blog'
import Quotes from './routes/Quotes'
import GroupChat from './routes/GroupChat'
import Signup from './routes/Signup'
import Login from './routes/Login'

export default function App(){
  const tabs = [
    {path:'/',label:'Home'},
    {path:'/feza-news',label:'Feza News'},
    {path:'/feza-shop',label:'Feza Shop'},
    {path:'/clubs',label:'Clubs'},
    {path:'/blog',label:'Blog'},
    {path:'/career',label:'Career'},
    {path:'/moral',label:'Moral'},
    {path:'/quotes-of-the-day',label:'Quotes of the day'},
    {path:'/group-chat',label:'Group Chat'},
    {path:'/about-us',label:'About us'}
  ]

  return (
    <div className="min-h-screen bg-[#00113d] text-white">
      <header className="sticky top-0 backdrop-blur bg-black/40 p-4 flex items-center">
        <img src="/logo.png" alt="logo" className="h-16 mr-4" />
        <div className="flex-1">
          <div className="font-bold text-xl">Feza Schools Inter Youth Union</div>
          <div className="text-sm text-yellow-400">Unity is Strength</div>
        </div>
        <nav className="space-x-3 hidden md:block">
          {tabs.map(t=> <Link key={t.path} to={t.path} className={`px-3 py-1 rounded ${t.path==='/'?'bg-yellow-400 text-black':''}`}>{t.label}</Link>)}
        </nav>
        <div className="ml-4">
          <Link to="/login" className="px-3 py-1 border rounded">Login</Link>
          <Link to="/signup" className="px-3 py-1 bg-yellow-400 text-black rounded">Sign up</Link>
        </div>
      </header>

      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/quotes-of-the-day" element={<Quotes />} />
          <Route path="/group-chat" element={<GroupChat />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/login" element={<Login />} />
        </Routes>
      </main>

      <footer className="bg-[#000828] p-6 mt-8 text-sm">
        <div className="max-w-5xl mx-auto">© Feza Schools Inter Youth Union</div>
      </footer>
    </div>
  )
}
