import React, { useEffect, useState } from 'react'
import { collection, addDoc, query, orderBy, onSnapshot } from 'firebase/firestore'
import { db, storage } from '../firebase'
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage'

const CLASSES = ["1A","1B","1C","2A","2B","2C","3A","3B","3C","4A","4B","4C","5 Arts","5 Sci1","5 Sci2","6Arts","6Sci1","6Sci2"]

export default function GroupChat({ user }: any){
  const [selected,setSelected] = useState(CLASSES[0])
  const [messages,setMessages] = useState<any[]>([])
  const [text,setText] = useState('')
  const [file,setFile] = useState<File|null>(null)
  const [united,setUnited] = useState(false)

  useEffect(()=>{
    const col = collection(db, `${united? 'unitedChats':'groupChats'}/${selected}/messages`)
    const q = query(col, orderBy('timestamp'))
    return onSnapshot(q, snap=> setMessages(snap.docs.map(d=> ({id:d.id,...d.data()}))))
  },[selected,united])

  async function send(){
    if(!user) return alert('Please sign in')
    let mediaURL=null, mediaType=null
    if(file){
      const r = ref(storage, `chats/${Date.now()}_${file.name}`)
      await uploadBytes(r,file)
      mediaURL = await getDownloadURL(r)
      mediaType = file.type
    }
    await addDoc(collection(db, `${united? 'unitedChats':'groupChats'}/${selected}/messages`),{senderUid:user.uid, senderName:user.displayName||user.email, text, mediaURL, mediaType, timestamp:new Date()})
    setText(''); setFile(null)
  }

  return (
    <div className="p-4 max-w-4xl mx-auto">
      <h2 className="text-xl font-bold">Group Chat</h2>
      <div className="mt-2 flex gap-2 overflow-x-auto">
        {CLASSES.map(c=> <button key={c} onClick={()=>setSelected(c)} className={`px-3 py-1 rounded ${c===selected? 'bg-yellow-400 text-black':''}`}>{c}</button>)}
      </div>
      <div className="mt-3">
        <label className="flex items-center gap-2"> <input type="checkbox" checked={united} onChange={e=>setUnited(e.target.checked)} /> United chat (cross-school)</label>
      </div>
      <div className="mt-3 p-3 bg-[#071233] rounded h-80 overflow-y-auto">
        {messages.map(m=> (
          <div key={m.id} className="mb-2">
            <div className="text-sm font-semibold">{m.senderName}</div>
            <div>{m.text}</div>
            {m.mediaURL && (m.mediaType?.startsWith('image') ? <img src={m.mediaURL} className="max-h-40 mt-1"/> : (m.mediaType?.startsWith('video') ? <video src={m.mediaURL} controls className="w-full mt-1"/> : <audio src={m.mediaURL} controls className="w-full mt-1"/>))}
            <div className="text-xs text-gray-400">{new Date(m.timestamp?.toDate?.()||m.timestamp).toLocaleString()}</div>
          </div>
        ))}
      </div>
      <div className="mt-2 flex gap-2">
        <input value={text} onChange={e=>setText(e.target.value)} className="flex-1 p-2 rounded" placeholder="Type a message" />
        <input type="file" accept="image/*,video/*,audio/*" onChange={e=> setFile(e.target.files?.[0]||null)} />
        <button onClick={send} className="px-3 py-1 bg-yellow-400 text-black rounded">Send</button>
      </div>
    </div>
  )
}
