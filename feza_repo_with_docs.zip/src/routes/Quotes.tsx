import React, { useEffect, useState } from 'react'
import { collection, addDoc, onSnapshot, query, orderBy } from 'firebase/firestore'
import { db, storage } from '../firebase'
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage'

export default function Quotes({ user }: any){
  const [quotes, setQuotes] = useState<any[]>([])
  const [text, setText] = useState('')
  const [file, setFile] = useState<File|null>(null)

  useEffect(()=>{
    const q = query(collection(db,'quotes'), orderBy('createdAt','desc'))
    return onSnapshot(q, snap => setQuotes(snap.docs.map(d=> ({id:d.id,...d.data()}))))
  },[])

  async function submit(){
    if(!user) return alert('Sign up to post')
    let mediaURL=null, mediaType=null
    if(file){
      const r = ref(storage, `quotes/${Date.now()}_${file.name}`)
      await uploadBytes(r,file)
      mediaURL = await getDownloadURL(r)
      mediaType = file.type
    }
    await addDoc(collection(db,'quotes'),{author:user.uid, authorName:user.displayName||user.email, text, mediaURL, mediaType, createdAt:new Date(), status:'pending'})
    setText(''); setFile(null)
  }

  return (
    <div className="p-4 max-w-4xl mx-auto">
      <h2 className="text-xl font-bold">Quotes of the Day</h2>
      {user && (
        <div className="mt-3 p-3 bg-[#071233] rounded">
          <textarea value={text} onChange={e=>setText(e.target.value)} className="w-full p-2 rounded" placeholder="Write a moral quote..." />
          <input type="file" accept="image/*,video/*,audio/*" onChange={e=> setFile(e.target.files?.[0]||null)} className="mt-2" />
          <div className="text-right mt-2"><button onClick={submit} className="px-3 py-1 bg-yellow-400 text-black rounded">Post Quote</button></div>
        </div>
      )}
      <div className="mt-4 space-y-3">
        {quotes.map(q=> (
          <div key={q.id} className="p-3 bg-[#071233] rounded">
            <div className="italic">"{q.text}"</div>
            {q.mediaURL && (q.mediaType?.startsWith('image') ? <img src={q.mediaURL} className="mt-2 max-h-60"/> : (q.mediaType?.startsWith('video') ? <video src={q.mediaURL} controls className="mt-2 w-full"/> : <audio src={q.mediaURL} controls className="mt-2 w-full"/>))}
            <div className="text-xs text-gray-400">— {q.authorName}</div>
          </div>
        ))}
      </div>
    </div>
  )
}
