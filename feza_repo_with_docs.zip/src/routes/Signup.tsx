import React, { useState } from 'react'
import { createUserWithEmailAndPassword } from 'firebase/auth'
import { auth, db } from '../firebase'
import { collection, setDoc, doc, query, limit, getDocs, serverTimestamp } from 'firebase/firestore'
import { useNavigate } from 'react-router-dom'

export default function Signup(){
  const [fullNames,setFullNames] = useState('')
  const [email,setEmail] = useState('')
  const [phone,setPhone] = useState('')
  const [school,setSchool] = useState("FEZA BOYS'")
  const [sex,setSex] = useState('Male')
  const [username,setUsername] = useState('')
  const [password,setPassword] = useState('')
  const [error,setError] = useState('')
  const navigate = useNavigate()

  async function handleSignup(e:any){
    e.preventDefault()
    try{
      let signupEmail = email
      if(!signupEmail) signupEmail = `${username || Date.now()}@fezau.local`
      const cred = await createUserWithEmailAndPassword(auth, signupEmail, password)
      const user = cred.user

      // Determine role: if there are no users yet, this user becomes supreme_admin
      const usersQuery = query(collection(db,'users'), limit(1))
      const snaps = await getDocs(usersQuery)
      let role = 'local_user'
      if (snaps.empty) role = 'supreme_admin'

      await setDoc(doc(db,'users',user.uid),{
        fullNames,
        email: email || null,
        phone: phone || null,
        school,
        sex,
        username,
        createdAt: serverTimestamp(),
        uid: user.uid,
        role
      })

      try{ await user.updateProfile({displayName: username}) }catch(e){}
      navigate('/')
    }catch(err:any){ setError(err.message) }
  }

  return (
    <div className="max-w-xl mx-auto p-4">
      <h2 className="text-xl font-bold">Sign up</h2>
      <form onSubmit={handleSignup} className="space-y-3 mt-3">
        <input required value={fullNames} onChange={e=>setFullNames(e.target.value)} placeholder="Full 3 names" className="w-full p-2 border rounded" />
        <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email (optional)" className="w-full p-2 border rounded" />
        <input value={phone} onChange={e=>setPhone(e.target.value)} placeholder="Phone (optional)" className="w-full p-2 border rounded" />
        <select value={school} onChange={e=>setSchool(e.target.value)} className="w-full p-2 border rounded">
          <option>FEZA BOYS'</option>
          <option>FEZA GIRLS'</option>
          <option>FEZA SHAMSIYE</option>
        </select>
        <select value={sex} onChange={e=>setSex(e.target.value)} className="w-full p-2 border rounded">
          <option>Male</option>
          <option>Female</option>
        </select>
        <input required value={username} onChange={e=>setUsername(e.target.value)} placeholder="Desired username" className="w-full p-2 border rounded" />
        <input required value={password} onChange={e=>setPassword(e.target.value)} type="password" placeholder="Password" className="w-full p-2 border rounded" />
        <div className="flex justify-between items-center">
          <button className="px-4 py-2 bg-blue-600 text-white rounded" type="submit">Sign up</button>
        </div>
      </form>
    </div>
  )
}
