import React, { useEffect, useState } from 'react'
import { db, storage } from '../firebase'
import { collection, addDoc, query, orderBy, onSnapshot } from 'firebase/firestore'
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage'

export default function Blog({ user }: any){
  const [posts,setPosts] = useState<any[]>([])
  const [text,setText] = useState('')
  const [file,setFile] = useState<File|null>(null)

  useEffect(()=>{
    const q = query(collection(db,'blogs'), orderBy('createdAt','desc'))
    return onSnapshot(q, snap=> setPosts(snap.docs.map(d=> ({id:d.id,...d.data()}))))
  },[])

  async function submit(){
    if(!user) return alert('Please sign in')
    let mediaURL = null, mediaType = null
    if(file){
      const r = ref(storage, `blogs/${Date.now()}_${file.name}`)
      await uploadBytes(r, file)
      mediaURL = await getDownloadURL(r)
      mediaType = file.type
    }
    await addDoc(collection(db,'blogs'),{author:user.uid, authorName:user.displayName||user.email, text, mediaURL, mediaType, createdAt:new Date(), likes:0})
    setText(''); setFile(null)
  }

  return (
    <div className="p-4 max-w-4xl mx-auto">
      <h2 className="text-xl font-bold">Blog</h2>
      {user && (
        <div className="mt-3 p-3 bg-[#071233] rounded">
          <textarea value={text} onChange={e=>setText(e.target.value)} className="w-full p-2 rounded" placeholder="Write your blog post..." />
          <input type="file" accept="image/*,video/*,audio/*" onChange={e=> setFile(e.target.files?.[0]||null)} className="mt-2" />
          <div className="text-right mt-2"><button onClick={submit} className="px-3 py-1 bg-yellow-400 text-black rounded">Post</button></div>
        </div>
      )}
      <div className="mt-4 space-y-3">
        {posts.map(p=> (
          <article key={p.id} className="p-3 bg-[#071233] rounded">
            <div className="text-sm text-gray-400">{p.authorName}</div>
            <div className="mt-2">{p.text}</div>
            {p.mediaURL && (
              p.mediaType?.startsWith('image') ? <img src={p.mediaURL} className="mt-2 max-h-60 object-contain" /> : (
                p.mediaType?.startsWith('video') ? <video controls src={p.mediaURL} className="mt-2 w-full"/> : <audio controls src={p.mediaURL} className="mt-2 w-full"/>
              )
            )}
            <div className="mt-2 flex items-center justify-between">
              <div>
                <button className="px-2 py-1 border rounded">Like ({p.likes||0})</button>
                <button className="px-2 py-1 border rounded ml-2">Comment</button>
                <button className="px-2 py-1 border rounded ml-2">Share</button>
              </div>
              <div className="text-xs text-gray-400">{new Date(p.createdAt?.toDate?.()||p.createdAt||Date.now()).toLocaleString()}</div>
            </div>
          </article>
        ))}
      </div>
    </div>
  )
}
