const functions = require('firebase-functions')
const admin = require('firebase-admin')
const { spawn } = require('child_process')
const path = require('path')
admin.initializeApp()

exports.scanUploadedFile = functions.storage.object().onFinalize(async (object) => {
  const filePath = object.name
  const bucket = admin.storage().bucket(object.bucket)
  const tmp = `/tmp/${path.basename(filePath)}`
  await bucket.file(filePath).download({destination: tmp})

  try{
    const scanner = spawn('clamscan', [tmp])
    let out = ''
    for await (const chunk of scanner.stdout) out += chunk
    const infected = out.includes('FOUND')
    if(infected){
      await bucket.file(filePath).delete()
      await admin.firestore().collection('alerts').add({type:'malware', filePath, details: out, time: admin.firestore.FieldValue.serverTimestamp()})
      await admin.firestore().collection('notifications').add({title: 'Malware detected', body: `File ${filePath} removed`, createdAt: admin.firestore.FieldValue.serverTimestamp()})
    } else {
      await admin.firestore().collection('fileMeta').doc(filePath).set({safe:true, scannedAt: admin.firestore.FieldValue.serverTimestamp()})
    }
  }catch(err){
    console.error('Scanner failed', err)
    await admin.firestore().collection('alerts').add({type:'scan_failed', filePath, error: String(err), time: admin.firestore.FieldValue.serverTimestamp()})
  }
})
