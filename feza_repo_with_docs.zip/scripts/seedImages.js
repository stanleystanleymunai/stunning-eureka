// scripts/seedImages.js - replace IMAGE_URLS with public image URLs you want to fetch
const admin = require('firebase-admin')
const fetch = require('node-fetch')
const { v4: uuidv4 } = require('uuid')
const path = require('path')
const serviceAccount = require('../serviceAccountKey.json')
admin.initializeApp({ credential: admin.credential.cert(serviceAccount), storageBucket: serviceAccount.project_id + '.appspot.com' })
const bucket = admin.storage().bucket()
const db = admin.firestore()

const IMAGE_URLS = [
  // replace these with Feza event images on the web
  'https://upload.wikimedia.org/wikipedia/commons/6/6c/Feza_logo_example.jpg'
]

async function uploadUrl(url){
  const res = await fetch(url)
  if(!res.ok) throw new Error('Failed to fetch')
  const ext = path.extname(url).split('?')[0] || '.jpg'
  const tmpName = `/tmp/${uuidv4()}${ext}`
  const buffer = await res.buffer()
  const file = bucket.file(`slides/${path.basename(tmpName)}`)
  await file.save(buffer, {metadata:{contentType: res.headers.get('content-type')}})
  const publicUrl = `https://storage.googleapis.com/${bucket.name}/${encodeURIComponent(file.name)}`
  await db.collection('slides').add({url: publicUrl, source:url, createdAt: admin.firestore.FieldValue.serverTimestamp()})
  console.log('Uploaded', publicUrl)
}

async function run(){
  for(const u of IMAGE_URLS) await uploadUrl(u)
}
run().catch(console.error)
